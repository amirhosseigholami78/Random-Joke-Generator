const button = document.querySelector('.container button');
const jokeText = document.querySelector('.container p');
// document.addEventListener('DOMContentLoaded', getJoke) 
// if you activate the line above for the first time , and in the beginning you will not be able to see the default text and you will face a joke :)   

button.addEventListener('click', getJoke);

async function getJoke(){
    const jokeData = await fetch("https://icanhazdadjoke.com/",{
        headers: {
            Accept: "application/json"
          }
    });
    const jokeObj = await jokeData.json();
    jokeText.innerHTML = jokeObj.joke
}
